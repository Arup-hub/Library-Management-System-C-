﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class AddMember : Form
    {
        public AddMember()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirm","Alert", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtMemberName.Clear();
            txtEnrolId.Clear();
            txtContactNumber.Clear();
            txtEmail.Clear();
            txtAddress.Clear();

        }

        private void btnSaveInfo_Click(object sender, EventArgs e)
        {
            if (txtMemberName.Text != "" && txtEnrolId.Text != "" &&  txtContactNumber.Text != "" && txtEmail.Text != "" && txtAddress.Text != "" )
            {
                String name = txtMemberName.Text;
                String enroll = txtEnrolId.Text;
                String email = txtEmail.Text;
                String address = txtAddress.Text;
                Int64 mobile = Int64.Parse(txtContactNumber.Text);

                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                con.Open();
                cmd.CommandText = "insert into NewMember(memname, enroll, contact, email, addres) values('" + name + "','" + enroll + "'," + mobile + ",'" + email + "','" + address + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Data Saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please Fill Empty Fields","Suggest",MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void AddMember_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
