﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtUserid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-P7J7SJ19; database=LibraryManagementSystem; integrated security=True ";
            SqlCommand cmd = new SqlCommand("select * from loginTable where userid ='" + txtUserid.Text + "' and pass ='" + txtPassword.Text + "' ", con);
            cmd.Connection = con;

           // cmd.CommandText = "select * from loginTable where userid ='"+txtUserid.Text+"' and pass ='"+txtPassword.Text+"' ",con;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
          //  DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(dt);

            string cmbItemValue = comboBox1.SelectedItem.ToString();

            if(dt.Rows.Count>0/*ds.Tables[0].Rows.Count != 0*/)
            {
                //this.Hide();
                //Dashboard dsb = new Dashboard();
                //dsb.Show();
                for(int i=0; i<dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["usertype"].ToString()==cmbItemValue)
                    {
                        MessageBox.Show("you are login as "+dt.Rows[i][3]);
                        if(comboBox1.SelectedIndex==0)
                        {
                            this.Hide();
                            Receptionist rcpt = new Receptionist();
                            rcpt.Show();
                            
                           

                        }
                        else 
                        {
                            this.Hide();
                            Librarian lb = new Librarian();
                            lb.Show();
                           

                        }
                       
                        
                    }

                }

            }
            else
            {
                MessageBox.Show("Wrong User Id or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void rbtnLibrarian_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnReciptionist_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
