﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class IssueBooks : Form
    {
        public IssueBooks()
        {
            InitializeComponent();
        }

        private void IssueBooks_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            con.Open();
            cmd= new SqlCommand("select bName from NewBook",con);
            SqlDataReader sdr = cmd.ExecuteReader();

            while(sdr.Read()) // it will exicute 10 rows if table has 10 then it will stop exicute
            {
                for(int i = 0; i < sdr.FieldCount; i++)
                {
                    comboBoxBooks.Items.Add(sdr.GetString(i));
                }

            }
            sdr.Close();
            con.Close();

        }

        int count;
        private void btnSearchMember_Click(object sender, EventArgs e)
        {
            if(txtSearch.Text != null)
            {
                String edi=txtSearch.Text;
                
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandText = "select * from NewMember where enroll='" + edi + "'";
                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                //-----------------------------------------------------
                //code to count how many book has been issued on this enrollment number 

                cmd.CommandText = "select count(mem_enroll) from IRBook where mem_enroll='" + edi + "'and book_return_date is null";
                SqlDataAdapter DA1 = new SqlDataAdapter(cmd);
                DataSet DS1 = new DataSet();
                DA.Fill(DS1);

                count = int.Parse(DS1.Tables[0].Rows[0][0].ToString());

                //-----------------------------------------------------


                if (DS.Tables[0].Rows.Count !=0) //Can't pass null values in the text box. 
                {
                    txtName.Text=DS.Tables[0].Rows[0][1].ToString();
                    txtContact.Text = DS.Tables[0].Rows[0][3].ToString();
                    txtEmail.Text=DS.Tables[0].Rows [0][4].ToString();
                    txtAddress.Text=DS.Tables[0].Rows[0][5].ToString();
                }
                else 
                {
                    txtName.Clear();
                    txtContact.Clear();
                    txtEmail.Clear();
                    txtAddress.Clear();
                    MessageBox.Show("Invalid Enrollment No","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);

                }
            }
        }

        private void btnIssueBook_Click(object sender, EventArgs e)
        {
            if(txtName.Text !=null)
            {
                if(comboBoxBooks.SelectedIndex !=-1 && count<= 2)
                {
                    String enroll = txtSearch.Text;
                    String name = txtName.Text;
                    Int64 contact = Int64.Parse(txtContact.Text);                   
                    String email = txtEmail.Text;
                    String address = txtAddress.Text;
                    String bookname = comboBoxBooks.Text;
                    String bookIssueDate = dateTimePicker.Text;

                    String edi = txtSearch.Text;

                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                   
                    con.Open();
                    cmd.CommandText = "insert into IRBook (mem_enroll,mem_name,mem_contact,mem_email,mem_address,book_name,book_issue_date) values('"+enroll+ "','"+name+ "',"+contact+ ",'"+email+ "','"+address+ "','"+bookname+ "','"+bookIssueDate+"')";
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Book Issued.","Success",MessageBoxButtons.OK,MessageBoxIcon.Information);

                }
                else
                {
                    MessageBox.Show("Select Book or Maximum Number of Book has been Issued.", "NO Book Selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Enter valid Enrollment No", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if(txtSearch.Text == null)
            {
                txtName.Clear();
                txtContact.Clear();
                txtEmail.Clear();
                txtAddress.Clear();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)==DialogResult.OK);
            {
                this.Close();
            }
            
        }
    }
}
