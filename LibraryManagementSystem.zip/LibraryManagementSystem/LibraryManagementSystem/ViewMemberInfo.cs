﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class ViewMemberInfo : Form
    {
        public ViewMemberInfo()
        {
            InitializeComponent();
        }


        private void txtSearchEnrollement_TextChanged(object sender, EventArgs e)
        {
            if (txtSearchEnrollement.Text != "")
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandText = "select * from NewMember where enroll LIKE '" + txtSearchEnrollement.Text + "%'";
                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];
            }
            else 
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandText = "select * from NewMember";
                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);
                dataGridView1.DataSource = DS.Tables[0];

            }


        }


        private void ViewMemberInfo_Load(object sender, EventArgs e)
        {
            panel2.Visible = false;
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            cmd.CommandText = "select * from NewMember";
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DataSet DS= new DataSet();
            DA.Fill(DS);
            dataGridView1.DataSource = DS.Tables[0];


        }

        int bid;
        Int64 rowid;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value !=null)
            {
                bid = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
            panel2.Visible = true;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            cmd.CommandText = "select * from NewMember where memid = "+bid+" ";
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DataSet DS = new DataSet();
            DA.Fill(DS);


            rowid = Int64.Parse(DS.Tables[0].Rows[0][0].ToString());

            txtMemberName.Text = DS.Tables[0].Rows[0][1].ToString();
            txtEnrollMentNo.Text = DS.Tables[0].Rows[0][2].ToString();
            txtContact.Text = DS.Tables[0].Rows[0][3].ToString();
            txtEmail.Text = DS.Tables[0].Rows[0][4].ToString();
            txtAddress.Text = DS.Tables[0].Rows[0][5].ToString();
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Data Will be Updated. Confirm?", "Success", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                String memname = txtMemberName.Text;
                String enroll = txtEnrollMentNo.Text;
                Int64 contact = Int64.Parse(txtContact.Text);
                String email = txtEmail.Text;
                String addres = txtAddress.Text;
              
               

                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandText = "update NewMember set memname='" + memname + "',enroll='" + enroll + "',contact=" + contact + ",email='" + email + "',addres='" + addres + "' where memid=" + rowid + " ";
                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                ViewMemberInfo_Load(this, null);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Data Will be Deleted. Confirm?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                String memname = txtMemberName.Text;
                String enroll = txtEnrollMentNo.Text;
                Int64 contact = Int64.Parse(txtContact.Text);
                String email = txtEmail.Text;
                String addres = txtAddress.Text;



                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =LAPTOP-P7J7SJ19; database = LibraryManagementSystem; integrated security=True ";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                cmd.CommandText = "delete from NewMember where memid="+rowid+"";
                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataSet DS = new DataSet();
                DA.Fill(DS);

                ViewMemberInfo_Load(this, null);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            ViewMemberInfo_Load(this, null);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Unsaved Data Will be Lost.","Are you sure?",MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)==DialogResult.OK)
            {
                this.Close();
            }
            
        }
    }
}
